//
// Created by tang zhige on 2019/3/13.
//

#ifndef LIBCZERO_INCLUDE_LIGHT_H
#define LIBCZERO_INCLUDE_LIGHT_H

#include "constant.h"

#endif //LIBCZERO_INCLUDE_LIGHT_H
